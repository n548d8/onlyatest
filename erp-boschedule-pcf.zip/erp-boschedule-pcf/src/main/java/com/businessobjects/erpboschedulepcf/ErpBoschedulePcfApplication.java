package com.businessobjects.erpboschedulepcf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErpBoschedulePcfApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErpBoschedulePcfApplication.class, args);
	}

}
