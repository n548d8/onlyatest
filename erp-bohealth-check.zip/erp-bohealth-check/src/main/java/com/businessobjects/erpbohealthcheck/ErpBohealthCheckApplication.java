package com.businessobjects.erpbohealthcheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErpBohealthCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErpBohealthCheckApplication.class, args);
	}

}
