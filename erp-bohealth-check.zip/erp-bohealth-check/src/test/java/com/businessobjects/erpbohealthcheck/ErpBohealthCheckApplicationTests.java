package com.businessobjects.erpbohealthcheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErpBohealthCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
