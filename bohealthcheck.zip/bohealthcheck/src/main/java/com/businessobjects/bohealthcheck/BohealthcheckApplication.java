package com.businessobjects.bohealthcheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BohealthcheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(BohealthcheckApplication.class, args);
	}

}
