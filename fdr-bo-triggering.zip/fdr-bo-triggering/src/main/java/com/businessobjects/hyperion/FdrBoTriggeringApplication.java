package com.businessobjects.hyperion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FdrBoTriggeringApplication {

	public static void main(String[] args) {
		SpringApplication.run(FdrBoTriggeringApplication.class, args);
	}

}
