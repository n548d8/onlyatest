package com.businessobjects.hyperion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FdrBoTriggeringApplicationTests {

	@Test
	void contextLoads() {
	}

}
